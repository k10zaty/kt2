export interface IProduct {
  title: string;
  price: number;
  img: string;
  id: number;
  isLiked: boolean;
}
