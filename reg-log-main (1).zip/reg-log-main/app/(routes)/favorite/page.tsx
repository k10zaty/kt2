import Footer from '@/app/shared/components/layout/Footer/Footer';

export default function Favorite() {
  return (
    <div>
      Favorite
      <Footer />
    </div>
  );
}
